<?php
class Properties {
    public static $chatgpt_key = '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';
}
?>
